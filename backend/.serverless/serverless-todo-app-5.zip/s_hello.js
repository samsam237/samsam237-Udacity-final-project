
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'samsam237',
  applicationName: 'serverless-todo-app-5',
  appUid: 'RnHTxZ0SG8mMJNhGLw',
  orgUid: 'cc631293-fd18-4cb2-9100-728fdca9dd6a',
  deploymentUid: '9a039d0d-c785-49a6-a0d7-dd13cd5475ea',
  serviceName: 'serverless-todo-app-5',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '6.2.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'serverless-todo-app-5-dev-hello', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.hello, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}